//========================================================================================================================
//
// CarExternalDInput
//
// This utilises the CarExternalInput interface provided in Edy's Vehicle Physics to provide input from Game Controller onto vehicle
//
//========================================================================================================================


#pragma strict

class CarExternalDInput extends CarExternalInput
{

private var wheelMenu : WheelMenu;
private var shiftUpOn : boolean = false;
private var shiftDownOn : boolean = false;
private var currentGear : int = 0;



function Awake () 
	{
	
	// Run Awake base code
	super();	
	
	// Get the wheel menu component.
	wheelMenu = Camera.main.GetComponent.<WheelMenu>(); 
	
	}
	
function InitCar()
{
}


function Update ()
	{

	// Get current state of game controller
	wheelMenu.dinput.GetInput();
	
	// Update car control with current inputs
	m_CarControl.steerInput = GetSteer();
	m_CarControl.motorInput = wheelMenu.dinput.GetThrottle();
	m_CarControl.brakeInput = wheelMenu.dinput.GetBrake();
	m_CarControl.handbrakeInput = wheelMenu.dinput.GetHandbrake();
	m_CarControl.gearInput = 1; //GetGear();
	
	
	}
	
private function GetSteer()
{
	var sensitivity : float;
        // Sensitivity is a logistics growth curve (S shaped curve) trends between 0.95f to 0. the 0.05f is a constant to ensure we always have some steering 
        //float sensitivity = (.95f / (1 + 0.02f * Mathf.Exp(0.025f * veloKmh))) + 0.05f;
        sensitivity = (.95f / (1 + 0.3f * Mathf.Exp(0.06f * Mathf.Abs(transform.InverseTransformDirection(rigidbody.velocity).z)))) + 0.05f;
        return wheelMenu.dinput.GetSteer(sensitivity);
    
}

private function GetGear() : int
    {
        if (!shiftUpOn && wheelMenu.dinput.ShiftUp())
        {
            ++currentGear;
            shiftUpOn = true;
        }
        else { shiftUpOn = false; }
        if (!shiftDownOn && wheelMenu.dinput.ShiftDown())
        {
            --currentGear;
            shiftDownOn = true;
        }
        else { shiftDownOn = false; }
        return currentGear;
    }
	
}