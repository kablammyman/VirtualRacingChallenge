using UnityEngine;
using System.Collections;

public class FFB : MonoBehaviour {

    CarDynamics carDynamics;
    Drivetrain drivetrain;
    CarCameras carCameras;
    WheelMenu wheelMenu;

	// Use this for initialization
	void Start () {
        carDynamics = transform.GetComponent<CarDynamics>();
        drivetrain = transform.GetComponent<Drivetrain>();
        carCameras = Camera.main.GetComponent<CarCameras>();

        // Only refer to WheelInput(dinput) through WheelMenu. 
        // This is to ensure when WheelMenu is destroyed, WheelInput is destroyed.
        wheelMenu = Camera.main.GetComponent<WheelMenu>();
	}
	
	// Update is called once per frame
	void Update () {
        if (carCameras.target.gameObject == this.gameObject)
        {
            wheelMenu.dinput.GetInput(); // if using direct input controller, then don't need to do this here
            wheelMenu.dinput.SetForceCoordinate((int)(carDynamics.forceFeedback/-1.8f));
            wheelMenu.dinput.SetLeds(drivetrain.rpm, drivetrain.minRPM + 1500, drivetrain.maxRPM + 1500);
        }
	}
}
